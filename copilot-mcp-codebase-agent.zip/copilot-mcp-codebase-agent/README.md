
# Copilot MCP Codebase Agent (Python)

This project is a **Python-based codebase intelligence backend** designed to be used as an **MCP server** by tools like **GitHub Copilot in VS Code**.

It:
- Walks and indexes your Java codebase.
- Stores code chunks + metadata in **Qdrant** (vector DB).
- Stores method/class relationships in **Neo4j** (graph DB).
- Exposes **MCP tools** (search_code, find_callers, find_callees, trace_path, get_file).

It does **not** call any external LLM APIs. Copilot's LLM does all reasoning; this service only provides code + graph data.

---

## 1. Prerequisites

- Python 3.11
- Docker + Docker Compose
- Neo4j & Qdrant will be started by `docker-compose`.
- GitHub Copilot / MCOP in VS Code (as MCP client).

No OpenAI / Anthropic API keys are required.

---

## 2. Files overview

- `agent_config.yaml` — main runtime config (codebase path, Qdrant, Neo4j, security).
- `.env.template` — template for secrets; copy to `.env` and fill.
- `docker-compose.yml` — Qdrant + Neo4j + this agent.
- `Dockerfile` — container for FastAPI app.
- `requirements.txt` — Python dependencies.
- `app/` — source code for the agent.

---

## 3. Configuration

### 3.1 Codebase source

Edit `agent_config.yaml` and set the codebase root:

```yaml
source:
  local_path: "/opt/projects/ubs-oms"  # path inside host, mounted into container
```

Make sure your repo is available under `/opt/projects` on the host (or change the mount in `docker-compose.yml`).

### 3.2 Indexing settings

```yaml
indexing:
  include_extensions: [".java", ".xml", ".yaml", ".yml", ".properties", ".md"]
  exclude_paths: ["target/", "generated-sources/", "test-doubles/", ".git/", "node_modules/"]
  skip_generated_code: true
```

### 3.3 Qdrant & Neo4j

```yaml
qdrant:
  url: "http://qdrant:6333"
  collection_name: "codebase"
  vector_size: 384

neo4j:
  uri: "bolt://neo4j:7687"
  username: "neo4j"
  password_env: "NEO4J_PASSWORD"
  max_traversal_depth: 4
```

### 3.4 Security

```yaml
security:
  mcp_auth_token_env: "MCP_AUTH_TOKEN"
  webhook_secret_env: "WEBHOOK_SECRET"
```

- `MCP_AUTH_TOKEN` protects MCP endpoints.
- `WEBHOOK_SECRET` is used to verify git webhooks (optional).

---

## 4. Setup & Run

### 4.1 Prepare environment

```bash
cp .env.template .env
vim .env   # set NEO4J_PASSWORD, MCP_AUTH_TOKEN, WEBHOOK_SECRET
```

### 4.2 Start Qdrant + Neo4j + Agent

```bash
docker-compose up --build
```

This will:
- Start Qdrant on `localhost:6333`.
- Start Neo4j on `localhost:7474` (browser) and `localhost:7687` (Bolt).
- Start the agent on `http://localhost:8000`.

### 4.3 Initial indexing

Once the agent is running, trigger indexing **once**:

```bash
curl -X POST http://localhost:8000/api/index
```

This will:
- Walk `source.local_path`.
- Parse files into coarse chunks.
- Embed chunks with a local embedding model.
- Store them in Qdrant.
- Create basic nodes in Neo4j.

Data in `./data/qdrant` and `./data/neo4j` will persist across restarts.

---

## 5. MCP tools

The agent exposes the following MCP endpoints:

- `GET /mcp/tools/list` — list of tools.
- `POST /mcp/tools/call` — invoke a tool.

Tools:

- `search_code`
  - Args: `query` (string), `repo` (optional), `layer` (optional).
  - Returns: code snippets matching the query.
- `find_callers`
  - Args: `method` (string).
  - Returns: methods that call this method.
- `find_callees`
  - Args: `method` (string).
  - Returns: methods called by this method.

You can extend this with `trace_path`, `get_file`, etc.

All MCP requests must send:

```http
Authorization: Bearer <MCP_AUTH_TOKEN>
```

---

## 6. Using with GitHub Copilot in VS Code (conceptual)

1. Configure Copilot / MCOP to connect to this service as an MCP server.
   - Base URL: `http://localhost:8000`.
   - Auth: `Bearer <MCP_AUTH_TOKEN>`.
2. Copilot will call `/mcp/tools/list` to discover tools.
3. In Copilot Chat, ask questions like:
   - "Search code for order validation before sequencing."
   - "Find all callers of SequencerQueue.enqueue." 
4. Copilot's LLM will:
   - Call `search_code` / `find_callers` tools.
   - Use responses to produce explanations or patches.

---

## 7. What you may customize

- `agent_config.yaml`:
  - `source.local_path` — where your repo lives.
  - `indexing.include_extensions` / `exclude_paths` — what to index.
  - `qdrant.collection_name` — collection name per repo.
  - `neo4j.max_traversal_depth` — how far to walk CALLS chains.
- `app/ingestion/java_parser.py`:
  - Currently treats each `.java` file as one chunk.
  - You can swap this with a Tree-sitter or JavaParser-based method-level parser.
- `app/storage/call_graph.py`:
  - Currently creates only basic `Method` nodes.
  - You can extend it to create `CALLS` edges and module/layer tags.

---

## 8. Notes

- No external LLM is called. This backend is purely a **knowledge + graph + tools** provider.
- All "intelligence" is expected to happen in the MCP client (e.g. GitHub Copilot in VS Code).
- For large codebases, consider running indexing as a scheduled job or via git webhooks.
