
from fastapi import APIRouter
from app.ingestion.indexer import full_index

router = APIRouter()


@router.post("/index")
async def index() -> dict:
    count = full_index()
    return {"status": "ok", "chunks_indexed": count}
