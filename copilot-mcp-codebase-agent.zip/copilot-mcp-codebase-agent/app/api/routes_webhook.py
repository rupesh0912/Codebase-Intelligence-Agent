
from fastapi import APIRouter, Header, Body
from app.config import settings
import hmac
import hashlib
import json

router = APIRouter()


@router.post("/webhook/push")
async def git_webhook(
    payload: dict = Body(...),
    x_hub_signature_256: str | None = Header(default=None),
) -> dict:
    # Optional: GitHub-style signature verification
    if settings.webhook_secret and x_hub_signature_256:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        mac = hmac.new(settings.webhook_secret.encode("utf-8"), body, hashlib.sha256)
        expected = "sha256=" + mac.hexdigest()
        if not hmac.compare_digest(expected, x_hub_signature_256):
            return {"status": "unauthorized"}
    # For now just acknowledge; incremental indexing can be added later.
    return {"status": "ok"}
