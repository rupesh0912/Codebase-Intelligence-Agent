
from pathlib import Path
from pydantic_settings import BaseSettings
import yaml
import os

CONFIG_PATH = Path(os.getenv("AGENT_CONFIG", "agent_config.yaml")).resolve()

class Settings(BaseSettings):
    source_local_path: str
    indexing_include_extensions: list[str]
    indexing_exclude_paths: list[str]
    indexing_skip_generated_code: bool

    qdrant_url: str
    qdrant_collection_name: str
    qdrant_vector_size: int

    neo4j_uri: str
    neo4j_username: str
    neo4j_password: str
    neo4j_max_traversal_depth: int

    reranker_enabled: bool
    reranker_model_name: str
    reranker_top_n: int

    mcp_auth_token: str
    webhook_secret: str

    server_host: str = "0.0.0.0"
    server_port: int = 8000

    @classmethod
    def load(cls) -> "Settings":
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)

        return cls(
            source_local_path=raw["source"]["local_path"],
            indexing_include_extensions=raw["indexing"]["include_extensions"],
            indexing_exclude_paths=raw["indexing"]["exclude_paths"],
            indexing_skip_generated_code=raw["indexing"]["skip_generated_code"],
            qdrant_url=raw["qdrant"]["url"],
            qdrant_collection_name=raw["qdrant"]["collection_name"],
            qdrant_vector_size=raw["qdrant"]["vector_size"],
            neo4j_uri=raw["neo4j"]["uri"],
            neo4j_username=raw["neo4j"]["username"],
            neo4j_password=os.getenv(raw["neo4j"]["password_env"]),
            neo4j_max_traversal_depth=raw["neo4j"]["max_traversal_depth"],
            reranker_enabled=raw["reranker"]["enabled"],
            reranker_model_name=raw["reranker"]["model_name"],
            reranker_top_n=raw["reranker"]["top_n"],
            mcp_auth_token=os.getenv(raw["security"]["mcp_auth_token_env"]),
            webhook_secret=os.getenv(raw["security"]["webhook_secret_env"]),
            server_host=raw["server"]["host"],
            server_port=raw["server"]["port"],
        )

settings = Settings.load()
