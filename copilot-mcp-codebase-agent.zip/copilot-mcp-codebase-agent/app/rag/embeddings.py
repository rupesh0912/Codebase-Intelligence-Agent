
from sentence_transformers import SentenceTransformer
from functools import lru_cache


@lru_cache(maxsize=1)
def _embedding_model() -> SentenceTransformer:
    # You can change the model to another sentence-transformers model.
    return SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")


def embed_text(text: str) -> list[float]:
    model = _embedding_model()
    vec = model.encode(text, convert_to_numpy=True)
    return vec.tolist()
