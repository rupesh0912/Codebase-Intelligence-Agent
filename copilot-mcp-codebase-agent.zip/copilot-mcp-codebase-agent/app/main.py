
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.api.routes_index import router as index_router
from app.api.routes_webhook import router as webhook_router
from app.mcp.server import router as mcp_router
from app.storage.qdrant_store import QdrantStore
from app.storage.call_graph import CallGraph
from app.rag.embeddings import _embedding_model

app = FastAPI(title="Copilot MCP Codebase Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(index_router, prefix="/api", tags=["index"])
app.include_router(webhook_router, tags=["webhook"])
app.include_router(mcp_router, prefix="/mcp", tags=["mcp"])


@app.on_event("startup")
async def startup_event():
    # Eager initialization: Qdrant, Neo4j, embedding model
    store = QdrantStore()
    store.ensure_collection()

    graph = CallGraph()
    with graph.driver.session() as s:
        s.run("RETURN 1 AS ok").single()

    # Warm local embedding model
    _ = _embedding_model()


@app.get("/health/ready")
async def ready() -> dict:
    return {"status": "ready"}


if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.server_host, port=settings.server_port, reload=True)
