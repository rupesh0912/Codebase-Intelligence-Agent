
from pathlib import Path
from typing import Iterable
from app.config import settings


def walk_source(root: str | None = None) -> Iterable[Path]:
    root_path = Path(root or settings.source_local_path).resolve()
    include_ext = tuple(settings.indexing_include_extensions)
    exclude_paths = [p.strip("/") for p in settings.indexing_exclude_paths]

    for path in root_path.rglob("*"):
        rel = path.relative_to(root_path).as_posix()
        if any(rel.startswith(ex) for ex in exclude_paths):
            continue
        if path.is_file() and path.suffix in include_ext:
            yield path
