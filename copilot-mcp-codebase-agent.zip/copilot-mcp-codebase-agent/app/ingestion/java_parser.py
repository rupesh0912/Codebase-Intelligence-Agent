
"""Simplified Java parser.

For now, we treat each .java file as a single chunk. You can replace this
with a Tree-sitter or JavaParser-based parser that extracts methods, calls,
layer annotations, etc.
"""

from pathlib import Path
from hashlib import sha256
from app.ingestion.models import CodeChunk


def parse_java_file(path: Path, repo: str | None = None) -> list[CodeChunk]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    h = sha256(str(path).encode("utf-8")).hexdigest()
    return [
        CodeChunk(
            id=h,
            file_path=str(path),
            class_name=None,
            package_name=None,
            method_name=None,
            layer=None,
            annotations=[],
            calls=[],
            chunk_type="file",
            content=text,
            repo=repo,
            start_line=None,
            end_line=None,
        )
    ]
