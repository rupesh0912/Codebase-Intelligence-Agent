
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class CodeChunk:
    id: str
    file_path: str
    class_name: Optional[str]
    package_name: Optional[str]
    method_name: Optional[str]
    layer: Optional[str]
    annotations: List[str]
    calls: List[str]
    chunk_type: str
    content: str
    repo: Optional[str]
    start_line: Optional[int]
    end_line: Optional[int]
