
from app.config import settings
from app.ingestion.walker import walk_source
from app.ingestion.java_parser import parse_java_file
from app.ingestion.models import CodeChunk
from app.storage.qdrant_store import QdrantStore
from app.storage.call_graph import CallGraph

store = QdrantStore()
call_graph = CallGraph()


def full_index(repo: str | None = None) -> int:
    root = settings.source_local_path
    store.ensure_collection()
    count = 0

    for path in walk_source(root):
        if path.suffix == ".java":
            chunks = parse_java_file(path, repo=repo)
        else:
            text = path.read_text(encoding="utf-8", errors="ignore")
            chunks = [CodeChunk(
                id=str(path),
                file_path=str(path),
                class_name=None,
                package_name=None,
                method_name=None,
                layer=None,
                annotations=[],
                calls=[],
                chunk_type="file",
                content=text,
                repo=repo,
                start_line=None,
                end_line=None,
            )]

        for c in chunks:
            store.upsert_chunk(c)
            call_graph.update_from_chunk(c)
            count += 1

    return count
