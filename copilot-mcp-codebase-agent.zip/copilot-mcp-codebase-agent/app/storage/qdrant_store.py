
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from app.config import settings
from app.ingestion.models import CodeChunk
from app.rag.embeddings import embed_text
from typing import Dict, Any


class QdrantStore:
    def __init__(self) -> None:
        self.client = QdrantClient(url=settings.qdrant_url)
        self.collection = settings.qdrant_collection_name

    def ensure_collection(self) -> None:
        collections = self.client.get_collections().collections
        if self.collection not in [c.name for c in collections]:
            self.client.create_collection(
                collection_name=self.collection,
                vectors_config=VectorParams(
                    size=settings.qdrant_vector_size,
                    distance=Distance.COSINE,
                ),
            )

    def upsert_chunk(self, chunk: CodeChunk) -> None:
        vec = embed_text(chunk.content)
        payload: Dict[str, Any] = {
            "file_path": chunk.file_path,
            "class_name": chunk.class_name,
            "package_name": chunk.package_name,
            "method_name": chunk.method_name,
            "layer": chunk.layer,
            "annotations": chunk.annotations,
            "calls": chunk.calls,
            "chunk_type": chunk.chunk_type,
            "repo": chunk.repo,
            "content": chunk.content,
            "start_line": chunk.start_line,
            "end_line": chunk.end_line,
        }
        point = PointStruct(id=chunk.id, vector=vec, payload=payload)
        self.client.upsert(collection_name=self.collection, points=[point])

    def search(self, query: str, top_k: int = 10, filters: Dict[str, str] | None = None):
        vec = embed_text(query)
        query_filter = None
        if filters:
            from qdrant_client.models import Filter, FieldCondition, MatchValue
            must = [FieldCondition(key=k, match=MatchValue(value=v)) for k, v in filters.items()]
            query_filter = Filter(must=must)

        return self.client.search(
            collection_name=self.collection,
            query_vector=vec,
            limit=top_k,
            query_filter=query_filter,
            with_payload=True,
        )
