
from neo4j import GraphDatabase
from app.config import settings
from app.ingestion.models import CodeChunk
from typing import List


class CallGraph:
    def __init__(self) -> None:
        self.driver = GraphDatabase.driver(
            settings.neo4j_uri,
            auth=(settings.neo4j_username, settings.neo4j_password),
        )

    def close(self) -> None:
        self.driver.close()

    def update_from_chunk(self, chunk: CodeChunk) -> None:
        # With a richer parser, you would also create CALLS edges here.
        if not chunk.method_name:
            return
        with self.driver.session() as session:
            session.run(
                "MERGE (m:Method {name:$name, file:$file})",
                name=chunk.method_name,
                file=chunk.file_path,
            )

    def find_callers(self, method_name: str) -> List[str]:
        with self.driver.session() as s:
            result = s.run(
                "MATCH (caller:Method)-[:CALLS]->(m:Method {name:$name}) RETURN caller.name AS name",
                name=method_name,
            )
            return [r["name"] for r in result]

    def find_callees(self, method_name: str) -> List[str]:
        with self.driver.session() as s:
            result = s.run(
                "MATCH (m:Method {name:$name})-[:CALLS]->(callee:Method) RETURN callee.name AS name",
                name=method_name,
            )
            return [r["name"] for r in result]

    def trace_path(self, frm: str, to: str) -> List[list[str]]:
        with self.driver.session() as s:
            result = s.run(
                f"MATCH p=(a:Method {{name:$from}})-[:CALLS*1..{settings.neo4j_max_traversal_depth}]->(b:Method {{name:$to}}) "
                "RETURN [n IN nodes(p) | n.name] AS chain",
                from=frm,
                to=to,
            )
            return [r["chain"] for r in result]
