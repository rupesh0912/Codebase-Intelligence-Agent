
from fastapi import APIRouter, Header
from typing import Dict, Any
from app.config import settings
from app.storage.qdrant_store import QdrantStore
from app.storage.call_graph import CallGraph

router = APIRouter()
_store = QdrantStore()
_graph = CallGraph()


def _authorized(auth: str | None) -> bool:
    return auth == f"Bearer {settings.mcp_auth_token}" if settings.mcp_auth_token else False


@router.get("/tools/list")
async def list_tools(authorization: str | None = Header(default=None)) -> Dict[str, Any]:
    if not _authorized(authorization):
        return {"error": "unauthorized"}
    return {
        "tools": [
            {
                "name": "search_code",
                "description": "Search the codebase by natural language query",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "layer": {"type": "string"}
                    },
                    "required": ["query"]
                },
            },
            {
                "name": "find_callers",
                "description": "Find methods that call the given method",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "method": {"type": "string"}
                    },
                    "required": ["method"]
                },
            },
            {
                "name": "find_callees",
                "description": "Find methods called by the given method",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "method": {"type": "string"}
                    },
                    "required": ["method"]
                },
            },
        ]
    }


@router.post("/tools/call")
async def call_tool(
    body: Dict[str, Any],
    authorization: str | None = Header(default=None),
) -> Dict[str, Any]:
    if not _authorized(authorization):
        return {"error": "unauthorized"}

    name = body.get("name")
    args = body.get("arguments", {})

    if name == "search_code":
        query = args.get("query", "")
        layer = args.get("layer")
        filters = {"layer": layer} if layer else None
        hits = _store.search(query, top_k=10, filters=filters)
        chunks = []
        for h in hits:
            p = h.payload
            chunks.append(
                f"FILE: {p.get('file_path')}
METHOD: {p.get('method_name')}
---
{p.get('content')}"
            )
        joined = "

====

".join(chunks)
        return {"content": [{"type": "text", "text": joined}]}

    if name == "find_callers":
        method = args.get("method")
        callers = _graph.find_callers(method)
        txt = "Callers of " + method + ":
" + "
".join(callers)
        return {"content": [{"type": "text", "text": txt}]}

    if name == "find_callees":
        method = args.get("method")
        callees = _graph.find_callees(method)
        txt = "Callees of " + method + ":
" + "
".join(callees)
        return {"content": [{"type": "text", "text": txt}]}

    return {"error": f"unknown tool: {name}"}
