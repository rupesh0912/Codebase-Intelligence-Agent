# Codebase Intelligence Agent

RAG-based AI agent that indexes a Java codebase into a vector store and exposes intelligent
query capabilities via a REST API, GitHub Copilot Extension, and MCP Server Tool.

## Quick Start

### Step 1 — Configure
```bash
# Only file you need to edit:
vim agent-config.yml

# Set your project path or GitLab repo under `source:`
# Set API keys under `embedding:`, `llm:`
```

### Step 2 — Set secrets
```bash
cp .env.template .env
vim .env    # fill in all keys
```

### Step 3 — Start infrastructure
```bash
docker-compose up qdrant neo4j -d
```

### Step 4 — Build & run
```bash
mvn clean package -DskipTests
java -jar target/codebase-intelligence-agent-1.0.0-SNAPSHOT.jar
```

### Step 5 — Index your codebase
```bash
curl -X POST http://localhost:8080/api/index
# Watch logs — indexing runs async
```

### Step 6 — Query!
```bash
curl -X POST http://localhost:8080/api/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "How does order validation work?", "repo": "ubs-oms"}'

curl -X POST http://localhost:8080/api/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "What calls SequencerQueue.enqueue?", "repo": "ubs-oms"}'
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/ask | Natural language query (main endpoint) |
| POST | /api/index | Trigger full indexing |
| POST | /webhook/push | Git push webhook (incremental re-index) |
| GET  | /mcp/tools/list | MCP tool discovery |
| POST | /mcp/tools/call | MCP tool execution |
| POST | /copilot/webhook | GitHub Copilot Extension |
| GET  | /actuator/health | Health check |

## Architecture

```
Java Codebase → FileWalker → AstParser → Chunker → Embedder → Qdrant
                                       ↘ CallGraphService → Neo4j

Query → Embed → Qdrant search (top-10) → MiniLM Reranker (top-5) → Claude LLM → Answer + SourceRefs
```

## Download MiniLM Model
```bash
mkdir -p models
pip install optimum onnxruntime
optimum-cli export onnx --model cross-encoder/ms-marco-MiniLM-L-6-v2 models/
mv models/model.onnx models/ms-marco-MiniLM-L-6-v2.onnx
```
