package com.codebaseagent.api;

import lombok.Data;
import java.util.Map;

@Data
public class AskRequest {
    private String question;
    private String repo;
    private Map<String, String> filters;  // e.g. {"layer": "validator"}
}
