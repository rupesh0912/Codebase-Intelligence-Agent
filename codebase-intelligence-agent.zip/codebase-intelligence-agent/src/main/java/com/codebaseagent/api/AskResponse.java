package com.codebaseagent.api;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class AskResponse {
    private String answer;
    private List<SourceRef> sources;

    @Data
    @Builder
    public static class SourceRef {
        private String file;
        private String method;
        private int startLine;
        private int endLine;
    }
}
