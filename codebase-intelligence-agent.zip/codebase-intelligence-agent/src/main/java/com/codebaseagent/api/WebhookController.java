package com.codebaseagent.api;

import com.codebaseagent.AgentConfig;
import com.codebaseagent.ingestion.IngestionService;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.*;

@Slf4j
@RestController
@RequiredArgsConstructor
public class WebhookController {

    private final AgentConfig config;
    private final IngestionService ingestionService;

    @PostMapping("/webhook/push")
    public String handlePush(
            @RequestHeader(value = "X-Hub-Signature-256", required = false) String signature,
            @RequestBody JsonNode payload) {

        if (config.getWebhook().isEnabled() && !verifySignature(payload.toString(), signature)) {
            log.warn("Webhook signature mismatch — rejected");
            return "unauthorized";
        }

        List<String> changedFiles = new ArrayList<>();
        payload.path("commits").forEach(commit -> {
            commit.path("added").forEach(f -> changedFiles.add(f.asText()));
            commit.path("modified").forEach(f -> changedFiles.add(f.asText()));
        });

        String repoName = payload.path("repository").path("name").asText("default");
        String rootPath = resolveRootPath(repoName);
        String collection = resolveCollection(repoName);

        changedFiles.stream().filter(f -> f.endsWith(".java"))
                .map(f -> rootPath + "/" + f)
                .forEach(full -> ingestionService.reindexFile(full, repoName, collection));

        log.info("Webhook: re-indexed {} Java files for repo={}", changedFiles.size(), repoName);
        return "ok";
    }

    private boolean verifySignature(String body, String signature) {
        if (signature == null) return false;
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(config.getWebhook().getSecret().getBytes(), "HmacSHA256"));
            String computed = "sha256=" + HexFormat.of().formatHex(mac.doFinal(body.getBytes()));
            return computed.equals(signature);
        } catch (Exception e) { return false; }
    }

    private String resolveRootPath(String repo) {
        if (config.getRepos() == null) return config.getSource().getLocalPath();
        return config.getRepos().stream().filter(r -> r.getName().equals(repo))
                .map(AgentConfig.Repo::getLocalPath).findFirst().orElse(config.getSource().getLocalPath());
    }

    private String resolveCollection(String repo) {
        if (config.getRepos() == null) return config.getQdrant().getCollectionName();
        return config.getRepos().stream().filter(r -> r.getName().equals(repo))
                .map(AgentConfig.Repo::getCollection).findFirst().orElse(config.getQdrant().getCollectionName());
    }
}
