package com.codebaseagent.api;

import com.codebaseagent.AgentConfig;
import com.codebaseagent.agent.AgentOrchestrator;
import com.codebaseagent.ingestion.IngestionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AskController {

    private final AgentOrchestrator orchestrator;
    private final IngestionService ingestionService;
    private final AgentConfig config;

    /** Main RAG query endpoint */
    @PostMapping("/ask")
    public ResponseEntity<AskResponse> ask(@RequestBody AskRequest request) {
        return ResponseEntity.ok(orchestrator.ask(request));
    }

    /** Trigger full indexing for all configured repos */
    @PostMapping("/index")
    public ResponseEntity<String> triggerIndex() {
        if (config.getRepos() != null && !config.getRepos().isEmpty()) {
            config.getRepos().forEach(repo ->
                ingestionService.indexRepo(repo.getName(),
                        repo.getLocalPath() != null ? repo.getLocalPath() : config.getSource().getLocalPath(),
                        repo.getCollection()));
        } else {
            ingestionService.indexRepo("default", config.getSource().getLocalPath(), config.getQdrant().getCollectionName());
        }
        return ResponseEntity.ok("Indexing triggered asynchronously. Watch logs for progress.");
    }
}
