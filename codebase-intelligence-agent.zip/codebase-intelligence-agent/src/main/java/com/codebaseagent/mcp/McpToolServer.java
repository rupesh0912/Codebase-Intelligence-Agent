package com.codebaseagent.mcp;

import com.codebaseagent.AgentConfig;
import com.codebaseagent.agent.CodebaseAgentTools;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/mcp")
public class McpToolServer {

    private final CodebaseAgentTools tools;
    private final AgentConfig config;

    /** MCP tools listing — used by Claude Desktop to discover available tools */
    @GetMapping("/tools/list")
    public Object listTools(@RequestHeader("Authorization") String auth) {
        if (!authorized(auth)) return Map.of("error", "Unauthorized");
        return Map.of("tools", List.of(
            Map.of("name", "search_code",   "description", "Natural language codebase search",
                   "inputSchema", Map.of("query", "string", "repo", "string (optional)", "layer", "string (optional)")),
            Map.of("name", "find_callers",  "description", "Find all callers of a method",
                   "inputSchema", Map.of("method", "string (fully qualified)")),
            Map.of("name", "find_callees",  "description", "Find all methods called by a method",
                   "inputSchema", Map.of("method", "string")),
            Map.of("name", "trace_path",    "description", "Trace call chain between two methods",
                   "inputSchema", Map.of("from", "string", "to", "string")),
            Map.of("name", "get_file",      "description", "Get raw source file content",
                   "inputSchema", Map.of("file_path", "string")),
            Map.of("name", "git_blame",     "description", "Find author and commit for a file line",
                   "inputSchema", Map.of("file_path", "string", "line", "integer"))
        ));
    }

    /** MCP tool call dispatch */
    @PostMapping("/tools/call")
    public Object callTool(@RequestHeader("Authorization") String auth,
                           @RequestBody Map<String, Object> body) {
        if (!authorized(auth)) return Map.of("error", "Unauthorized");
        String name = (String) body.get("name");
        @SuppressWarnings("unchecked")
        Map<String, Object> args = (Map<String, Object>) body.getOrDefault("arguments", Map.of());

        String result = switch (name) {
            case "search_code"  -> tools.searchCode((String) args.get("query"),
                                        (String) args.getOrDefault("repo", ""),
                                        (String) args.getOrDefault("layer", ""));
            case "find_callers" -> tools.findCallers((String) args.get("method"));
            case "find_callees" -> tools.findCallees((String) args.get("method"));
            case "trace_path"   -> tools.tracePath((String) args.get("from"), (String) args.get("to"));
            case "get_file"     -> tools.getFile((String) args.get("file_path"));
            case "git_blame"    -> tools.gitBlame((String) args.get("file_path"),
                                        Integer.parseInt(args.get("line").toString()));
            default             -> "Unknown tool: " + name;
        };

        return Map.of("content", List.of(Map.of("type", "text", "text", result)));
    }

    private boolean authorized(String auth) {
        return ("Bearer " + config.getMcp().getAuthToken()).equals(auth);
    }
}
