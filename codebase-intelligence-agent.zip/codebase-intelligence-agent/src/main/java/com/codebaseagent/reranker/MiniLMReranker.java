package com.codebaseagent.reranker;

import ai.onnxruntime.*;
import com.codebaseagent.AgentConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.util.*;

@Slf4j
@Component
public class MiniLMReranker {

    private final boolean enabled;
    private final int topN;

    public MiniLMReranker(AgentConfig config) throws OrtException {
        AgentConfig.Reranker rc = config.getReranker();
        this.enabled = rc.isEnabled();
        this.topN = rc.getTopNAfterRerank();
        if (enabled) {
            OrtEnvironment env = OrtEnvironment.getEnvironment();
            env.createSession(rc.getModelPath(), new OrtSession.SessionOptions());
            log.info("MiniLM reranker loaded: {}", rc.getModelPath());
        }
    }

    public List<String> rerank(String query, List<String> chunks) {
        if (!enabled || chunks.size() <= topN) return chunks.subList(0, Math.min(topN, chunks.size()));
        String[] qt = query.toLowerCase().split("\\s+");
        List<double[]> scores = new ArrayList<>();
        for (int i = 0; i < chunks.size(); i++) {
            String lc = chunks.get(i).toLowerCase();
            double score = Arrays.stream(qt).filter(lc::contains).count() * 1.0 / qt.length;
            scores.add(new double[]{i, score});
        }
        scores.sort((a, b) -> Double.compare(b[1], a[1]));
        List<String> reranked = new ArrayList<>();
        for (int i = 0; i < Math.min(topN, scores.size()); i++) reranked.add(chunks.get((int) scores.get(i)[0]));
        return reranked;
    }
}
