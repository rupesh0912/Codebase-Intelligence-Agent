package com.codebaseagent.agent;

import com.codebaseagent.AgentConfig;
import com.codebaseagent.graph.CallGraphService;
import com.codebaseagent.ingestion.Embedder;
import com.codebaseagent.ingestion.QdrantStore;
import dev.langchain4j.agent.tool.Tool;
import io.qdrant.client.grpc.Points.ScoredPoint;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class CodebaseAgentTools {

    private final AgentConfig config;
    private final Embedder embedder;
    private final QdrantStore qdrantStore;
    private final CallGraphService callGraphService;

    @Tool("Search codebase by natural language. Filter by repo and layer optionally.")
    public String searchCode(String query, String repo, String layer) {
        try {
            float[] vector = embedder.embedToFloats(query);
            String collection = resolveCollection(repo);
            Map<String, String> filters = (layer != null && !layer.isBlank()) ? Map.of("layer", layer) : null;
            List<ScoredPoint> hits = qdrantStore.search(collection, vector, config.getQdrant().getTopKRetrieval(), filters);
            return hits.stream().map(p -> {
                String f = p.getPayload().getOrDefault("file_path", com.google.protobuf.Value.getDefaultInstance()).getStringValue();
                String m = p.getPayload().getOrDefault("method_name", com.google.protobuf.Value.getDefaultInstance()).getStringValue();
                String c = p.getPayload().getOrDefault("content", com.google.protobuf.Value.getDefaultInstance()).getStringValue();
                return "[" + f + "#" + m + "]\n" + c;
            }).collect(Collectors.joining("\n\n---\n\n"));
        } catch (Exception e) { return "Error: " + e.getMessage(); }
    }

    @Tool("Find all methods that call the given method name.")
    public String findCallers(String methodName) {
        List<String> r = callGraphService.findCallers(methodName);
        return r.isEmpty() ? "No callers for: " + methodName : "Callers:\n" + String.join("\n", r);
    }

    @Tool("Find all methods called by the given method.")
    public String findCallees(String methodName) {
        List<String> r = callGraphService.findCallees(methodName);
        return r.isEmpty() ? "No callees for: " + methodName : "Callees:\n" + String.join("\n", r);
    }

    @Tool("Trace call path between two methods.")
    public String tracePath(String from, String to) {
        List<String> r = callGraphService.tracePath(from, to);
        return r.isEmpty() ? "No path: " + from + " to " + to : "Chains:\n" + String.join("\n", r);
    }

    @Tool("Get raw source file content by full file path.")
    public String getFile(String filePath) {
        try { return Files.readString(Path.of(filePath)); }
        catch (IOException e) { return "Cannot read: " + e.getMessage(); }
    }

    @Tool("Run git blame on a file at a specific line.")
    public String gitBlame(String filePath, int line) {
        try {
            Process p = new ProcessBuilder("git", "blame", "-L", line + "," + line, "--porcelain", filePath)
                    .redirectErrorStream(true).start();
            return new String(p.getInputStream().readAllBytes());
        } catch (Exception e) { return "git blame failed: " + e.getMessage(); }
    }

    public String resolveCollection(String repo) {
        if (repo == null || repo.isBlank() || config.getRepos() == null) return config.getQdrant().getCollectionName();
        return config.getRepos().stream().filter(r -> r.getName().equals(repo))
                .map(AgentConfig.Repo::getCollection).findFirst().orElse(config.getQdrant().getCollectionName());
    }
}
