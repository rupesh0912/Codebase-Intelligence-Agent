package com.codebaseagent.agent;

import com.codebaseagent.AgentConfig;
import com.codebaseagent.api.AskRequest;
import com.codebaseagent.api.AskResponse;
import com.codebaseagent.ingestion.Embedder;
import com.codebaseagent.ingestion.QdrantStore;
import com.codebaseagent.reranker.MiniLMReranker;
import dev.langchain4j.model.anthropic.AnthropicChatModel;
import dev.langchain4j.model.chat.ChatLanguageModel;
import io.qdrant.client.grpc.Points.ScoredPoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AgentOrchestrator {

    private final ChatLanguageModel llm;
    private final Embedder embedder;
    private final QdrantStore qdrantStore;
    private final MiniLMReranker reranker;
    private final AgentConfig config;

    public AgentOrchestrator(AgentConfig config, Embedder embedder,
                              QdrantStore qdrantStore, MiniLMReranker reranker) {
        this.config = config; this.embedder = embedder;
        this.qdrantStore = qdrantStore; this.reranker = reranker;
        AgentConfig.Llm lc = config.getLlm();
        if ("anthropic".equalsIgnoreCase(lc.getProvider())) {
            this.llm = AnthropicChatModel.builder()
                    .apiKey(lc.getAnthropic().getApiKey())
                    .modelName(lc.getAnthropic().getModel())
                    .maxTokens(lc.getAnthropic().getMaxTokens()).build();
        } else {
            throw new IllegalArgumentException("Unsupported LLM provider: " + lc.getProvider());
        }
    }

    public AskResponse ask(AskRequest request) {
        try {
            float[] qv = embedder.embedToFloats(request.getQuestion());
            String col = resolveCollection(request.getRepo());
            List<ScoredPoint> hits = qdrantStore.search(col, qv, config.getQdrant().getTopKRetrieval(), request.getFilters());
            List<String> chunks = hits.stream().filter(p -> p.getPayload().containsKey("content"))
                    .map(p -> p.getPayload().get("content").getStringValue()).collect(Collectors.toList());
            List<String> top = reranker.rerank(request.getQuestion(), chunks);
            String context = String.join("\n\n---\n\n", top);
            String prompt = "You are a codebase intelligence assistant for a Java low-latency financial system.\n" +
                    "Answer using ONLY the code context. Reference class names, method names and file paths.\n" +
                    "QUESTION: " + request.getQuestion() + "\n\nCODE CONTEXT:\n" + context;
            String answer = llm.generate(prompt);
            List<AskResponse.SourceRef> sources = hits.stream().limit(config.getReranker().getTopNAfterRerank())
                    .map(p -> AskResponse.SourceRef.builder()
                            .file(p.getPayload().getOrDefault("file_path", com.google.protobuf.Value.getDefaultInstance()).getStringValue())
                            .method(p.getPayload().getOrDefault("method_name", com.google.protobuf.Value.getDefaultInstance()).getStringValue())
                            .startLine((int) p.getPayload().getOrDefault("start_line", com.google.protobuf.Value.getDefaultInstance()).getNumberValue())
                            .endLine((int) p.getPayload().getOrDefault("end_line", com.google.protobuf.Value.getDefaultInstance()).getNumberValue())
                            .build()).collect(Collectors.toList());
            return AskResponse.builder().answer(answer).sources(sources).build();
        } catch (Exception e) {
            log.error("ask failed: {}", e.getMessage(), e);
            return AskResponse.builder().answer("Error: " + e.getMessage()).sources(List.of()).build();
        }
    }

    private String resolveCollection(String repo) {
        if (repo == null || repo.isBlank() || config.getRepos() == null) return config.getQdrant().getCollectionName();
        return config.getRepos().stream().filter(r -> r.getName().equals(repo))
                .map(AgentConfig.Repo::getCollection).findFirst().orElse(config.getQdrant().getCollectionName());
    }
}
