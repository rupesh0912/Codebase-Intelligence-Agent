package com.codebaseagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableConfigurationProperties(AgentConfig.class)
@EnableAsync
public class CodebaseAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(CodebaseAgentApplication.class, args);
    }
}
