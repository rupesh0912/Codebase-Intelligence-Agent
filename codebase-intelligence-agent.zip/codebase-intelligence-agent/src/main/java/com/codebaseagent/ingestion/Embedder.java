package com.codebaseagent.ingestion;

import com.codebaseagent.AgentConfig;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.model.azure.AzureOpenAiEmbeddingModel;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.output.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.util.List;

@Slf4j
@Component
public class Embedder {

    private final EmbeddingModel embeddingModel;

    public Embedder(AgentConfig config) {
        AgentConfig.Embedding ec = config.getEmbedding();
        if ("azure_openai".equalsIgnoreCase(ec.getProvider())) {
            AgentConfig.Embedding.AzureOpenAI az = ec.getAzureOpenai();
            this.embeddingModel = AzureOpenAiEmbeddingModel.builder()
                    .endpoint(az.getEndpoint())
                    .apiKey(az.getApiKey())
                    .deploymentName(az.getDeploymentName())
                    .build();
        } else {
            throw new IllegalArgumentException("Unsupported embedding provider: " + ec.getProvider());
        }
        log.info("Embedder initialized with provider={}", ec.getProvider());
    }

    public float[] embedToFloats(String text) {
        Response<Embedding> response = embeddingModel.embed(text);
        List<Float> vec = response.content().vectorAsList();
        float[] arr = new float[vec.size()];
        for (int i = 0; i < vec.size(); i++) arr[i] = vec.get(i);
        return arr;
    }
}
