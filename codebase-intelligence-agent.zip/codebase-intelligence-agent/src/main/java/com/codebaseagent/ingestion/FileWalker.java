package com.codebaseagent.ingestion;

import com.codebaseagent.AgentConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class FileWalker {

    private final AgentConfig config;

    public List<Path> walk(String rootPath) throws IOException {
        List<Path> result = new ArrayList<>();
        AgentConfig.Indexing idx = config.getIndexing();

        Files.walkFileTree(Path.of(rootPath), new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                String rel = Path.of(rootPath).relativize(dir).toString();
                boolean excluded = idx.getExcludePaths().stream()
                        .anyMatch(ex -> rel.startsWith(ex) || rel.contains(ex));
                return excluded ? FileVisitResult.SKIP_SUBTREE : FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                String name = file.toString();
                boolean included = idx.getIncludeExtensions().stream().anyMatch(name::endsWith);
                if (included) result.add(file);
                return FileVisitResult.CONTINUE;
            }
        });
        log.info("FileWalker found {} files under {}", result.size(), rootPath);
        return result;
    }
}
