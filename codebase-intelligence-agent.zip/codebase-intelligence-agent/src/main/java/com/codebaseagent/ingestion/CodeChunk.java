package com.codebaseagent.ingestion;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class CodeChunk {
    private String id;
    private String filePath;
    private String className;
    private String packageName;
    private String methodName;
    private String layer;
    private List<String> annotations;
    private List<String> calls;
    private String chunkType;
    private String content;
    private String repo;
    private int startLine;
    private int endLine;
}
