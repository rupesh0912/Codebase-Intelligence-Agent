package com.codebaseagent.ingestion;

import com.codebaseagent.AgentConfig;
import io.qdrant.client.QdrantClient;
import io.qdrant.client.QdrantGrpcClient;
import io.qdrant.client.grpc.Collections.*;
import io.qdrant.client.grpc.Points.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ExecutionException;

import static io.qdrant.client.PointIdFactory.id;
import static io.qdrant.client.VectorsFactory.vectors;
import static io.qdrant.client.ValueFactory.value;

@Slf4j
@Component
public class QdrantStore {

    private final QdrantClient client;
    private final AgentConfig config;

    public QdrantStore(AgentConfig config) {
        this.config = config;
        AgentConfig.Qdrant qc = config.getQdrant();
        this.client = new QdrantClient(
                QdrantGrpcClient.newBuilder(qc.getHost(), qc.getPort(), qc.isUseTls()).build());
        log.info("QdrantStore connected at {}:{}", qc.getHost(), qc.getPort());
    }

    public void ensureCollection(String name) throws ExecutionException, InterruptedException {
        boolean exists = client.listCollectionsAsync().get().stream().anyMatch(c -> c.equals(name));
        if (!exists) {
            client.createCollectionAsync(name, VectorParams.newBuilder()
                    .setSize(config.getQdrant().getVectorSize())
                    .setDistance(Distance.Cosine).build()).get();
            log.info("Created Qdrant collection: {}", name);
        }
    }

    public void upsert(String collection, CodeChunk chunk, float[] vector)
            throws ExecutionException, InterruptedException {
        Map<String, Value> payload = Map.of(
            "file_path",   value(chunk.getFilePath()),
            "class_name",  value(chunk.getClassName()),
            "method_name", value(chunk.getMethodName()),
            "package_name",value(chunk.getPackageName()),
            "layer",       value(chunk.getLayer()),
            "chunk_type",  value(chunk.getChunkType()),
            "repo",        value(chunk.getRepo()),
            "content",     value(chunk.getContent()),
            "start_line",  value(chunk.getStartLine()),
            "end_line",    value(chunk.getEndLine())
        );
        client.upsertAsync(collection, List.of(
            PointStruct.newBuilder()
                .setId(id(UUID.nameUUIDFromBytes(chunk.getId().getBytes())))
                .setVectors(vectors(vector))
                .putAllPayload(payload)
                .build()
        )).get();
    }

    public void deleteByFilePath(String collection, String filePath)
            throws ExecutionException, InterruptedException {
        client.deleteAsync(collection, Filter.newBuilder().addMust(
            Condition.newBuilder().setField(FieldCondition.newBuilder()
                .setKey("file_path")
                .setMatch(Match.newBuilder().setKeyword(filePath)))
        ).build()).get();
    }

    public List<ScoredPoint> search(String collection, float[] queryVector,
                                    int topK, Map<String, String> filters)
            throws ExecutionException, InterruptedException {
        SearchPoints.Builder builder = SearchPoints.newBuilder()
                .setCollectionName(collection)
                .addAllVector(toFloatList(queryVector))
                .setLimit(topK)
                .setWithPayload(WithPayloadSelector.newBuilder().setEnable(true));
        if (filters != null && !filters.isEmpty()) {
            Filter.Builder fb = Filter.newBuilder();
            filters.forEach((k, v) -> fb.addMust(Condition.newBuilder().setField(
                FieldCondition.newBuilder().setKey(k).setMatch(Match.newBuilder().setKeyword(v)))));
            builder.setFilter(fb);
        }
        return client.searchAsync(builder.build()).get();
    }

    private List<Float> toFloatList(float[] arr) {
        List<Float> list = new ArrayList<>(arr.length);
        for (float v : arr) list.add(v);
        return list;
    }
}
