package com.codebaseagent.ingestion;

import com.codebaseagent.AgentConfig;
import com.codebaseagent.graph.CallGraphService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionService {

    private final AgentConfig config;
    private final FileWalker fileWalker;
    private final AstParser astParser;
    private final Embedder embedder;
    private final QdrantStore qdrantStore;
    private final CallGraphService callGraphService;

    @Async
    public void indexRepo(String repoName, String rootPath, String collection) {
        try {
            log.info("Indexing started: repo={}, path={}", repoName, rootPath);
            qdrantStore.ensureCollection(collection);
            List<Path> files = fileWalker.walk(rootPath);
            int total = 0;
            for (Path file : files) {
                if (file.toString().endsWith(".java")) {
                    for (CodeChunk chunk : astParser.parse(file, repoName)) {
                        float[] vector = embedder.embedToFloats(chunk.getContent());
                        qdrantStore.upsert(collection, chunk, vector);
                        callGraphService.storeCallEdges(chunk);
                        total++;
                    }
                }
            }
            log.info("Indexing complete: {} chunks for repo={}", total, repoName);
        } catch (Exception e) {
            log.error("Indexing failed for repo={}: {}", repoName, e.getMessage(), e);
        }
    }

    @Async
    public void reindexFile(String filePath, String repoName, String collection) {
        try {
            qdrantStore.deleteByFilePath(collection, filePath);
            List<CodeChunk> chunks = astParser.parse(Path.of(filePath), repoName);
            for (CodeChunk chunk : chunks) {
                qdrantStore.upsert(collection, chunk, embedder.embedToFloats(chunk.getContent()));
                callGraphService.storeCallEdges(chunk);
            }
            log.info("Re-indexed {} chunks for file={}", chunks.size(), filePath);
        } catch (Exception e) {
            log.error("Re-index failed for {}: {}", filePath, e.getMessage(), e);
        }
    }
}
