package com.codebaseagent.ingestion;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Slf4j
@Component
public class AstParser {

    public List<CodeChunk> parse(Path filePath, String repo) {
        List<CodeChunk> chunks = new ArrayList<>();
        try {
            CompilationUnit cu = StaticJavaParser.parse(filePath);
            String pkg = cu.getPackageDeclaration().map(p -> p.getName().asString()).orElse("");

            cu.findAll(ClassOrInterfaceDeclaration.class).forEach(clazz -> {
                String className = clazz.getNameAsString();
                List<String> classAnnotations = clazz.getAnnotations().stream()
                        .map(a -> "@" + a.getNameAsString()).toList();
                String layer = inferLayer(pkg, classAnnotations);

                clazz.getMethods().forEach(method -> {
                    List<String> calls = method.findAll(MethodCallExpr.class).stream()
                            .map(MethodCallExpr::getNameAsString).distinct().toList();

                    String content = String.format(
                        "Class: %s | Package: %s\nLayer: %s | Annotations: %s\nCalls: %s\n\nMethod: %s\n%s",
                        className, pkg, layer, classAnnotations, calls,
                        method.getDeclarationAsString(false, false, true), method.toString());

                    chunks.add(CodeChunk.builder()
                            .id(sha256(filePath + ":" + method.getNameAsString()))
                            .filePath(filePath.toString())
                            .className(className)
                            .packageName(pkg)
                            .methodName(method.getNameAsString())
                            .layer(layer)
                            .annotations(classAnnotations)
                            .calls(calls)
                            .chunkType("method")
                            .content(content)
                            .repo(repo)
                            .startLine(method.getBegin().map(p -> p.line).orElse(0))
                            .endLine(method.getEnd().map(p -> p.line).orElse(0))
                            .build());
                });
            });
        } catch (Exception e) {
            log.warn("Parse failed for {}: {}", filePath, e.getMessage());
        }
        return chunks;
    }

    private String inferLayer(String pkg, List<String> annotations) {
        if (pkg.contains("validator")) return "validator";
        if (pkg.contains("service")) return "service";
        if (pkg.contains("repository") || pkg.contains("repo")) return "repository";
        if (pkg.contains("controller") || pkg.contains("api")) return "controller";
        if (pkg.contains("gateway")) return "gateway";
        if (annotations.contains("@Service")) return "service";
        if (annotations.contains("@Repository")) return "repository";
        if (annotations.contains("@Controller") || annotations.contains("@RestController")) return "controller";
        return "unknown";
    }

    private String sha256(String input) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b));
            return hex.toString();
        } catch (Exception e) {
            return UUID.randomUUID().toString();
        }
    }
}
