package com.codebaseagent.copilot;

import com.codebaseagent.api.AskRequest;
import com.codebaseagent.api.AskResponse;
import com.codebaseagent.agent.AgentOrchestrator;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/copilot")
public class CopilotWebhookController {

    private final AgentOrchestrator orchestrator;
    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

    /**
     * GitHub Copilot Extension webhook.
     * Register this URL in your GitHub App settings as the webhook endpoint.
     * Streams response back as SSE (Server-Sent Events).
     */
    @PostMapping(value = "/webhook", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter handleCopilotRequest(@RequestBody JsonNode body,
                                            @RequestHeader(value = "X-GitHub-Token", required = false) String token) {
        SseEmitter emitter = new SseEmitter(60_000L);

        executor.submit(() -> {
            try {
                String userMessage = "";
                JsonNode messages = body.path("messages");
                for (JsonNode msg : messages) {
                    if ("user".equals(msg.path("role").asText())) {
                        userMessage = msg.path("content").asText();
                    }
                }
                AskRequest req = new AskRequest();
                req.setQuestion(userMessage);
                AskResponse response = orchestrator.ask(req);
                String escaped = response.getAnswer().replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
                emitter.send(SseEmitter.event().data("{\"choices\":[{\"delta\":{\"content\":\"" + escaped + "\"}}]}").name("message"));
                emitter.complete();
            } catch (Exception e) {
                emitter.completeWithError(e);
            }
        });
        return emitter;
    }
}
