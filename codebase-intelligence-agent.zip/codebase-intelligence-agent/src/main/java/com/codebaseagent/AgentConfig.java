package com.codebaseagent;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "")
public class AgentConfig {

    private Source source;
    private List<Repo> repos;
    private Indexing indexing;
    private Webhook webhook;
    private Qdrant qdrant;
    private Neo4j neo4j;
    private Embedding embedding;
    private Llm llm;
    private Reranker reranker;
    private Server server;
    private Copilot copilot;
    private Mcp mcp;

    @Data public static class Source {
        private String localPath;
        private Git git;

        @Data public static class Git {
            private String url;
            private String branch;
            private String cloneDir;
            private Credentials credentials;

            @Data public static class Credentials {
                private String type;
                private String token;
                private String sshKeyPath;
            }
        }
    }

    @Data public static class Repo {
        private String name;
        private String localPath;
        private String collection;
        private Source.Git git;
    }

    @Data public static class Indexing {
        private List<String> includeExtensions;
        private List<String> excludePaths;
        private boolean skipGeneratedCode;
        private String chunkStrategy;
        private int overlapLines;
        private boolean incremental;
    }

    @Data public static class Webhook {
        private boolean enabled;
        private String secret;
        private String path;
    }

    @Data public static class Qdrant {
        private String host;
        private int port;
        private boolean useTls;
        private String collectionName;
        private int vectorSize;
        private String searchMode;
        private int topKRetrieval;
    }

    @Data public static class Neo4j {
        private String uri;
        private String username;
        private String password;
        private int maxTraversalDepth;
    }

    @Data public static class Embedding {
        private String provider;
        private AzureOpenAI azureOpenai;
        private Ollama ollama;

        @Data public static class AzureOpenAI {
            private String endpoint;
            private String apiKey;
            private String deploymentName;
            private String apiVersion;
        }

        @Data public static class Ollama {
            private String baseUrl;
            private String model;
        }
    }

    @Data public static class Llm {
        private String provider;
        private Anthropic anthropic;
        private AzureOpenAI azureOpenai;

        @Data public static class Anthropic {
            private String apiKey;
            private String model;
            private int maxTokens;
        }

        @Data public static class AzureOpenAI {
            private String endpoint;
            private String apiKey;
            private String deploymentName;
        }
    }

    @Data public static class Reranker {
        private boolean enabled;
        private String modelPath;
        private int topNAfterRerank;
    }

    @Data public static class Server {
        private int port;
        private String host;
    }

    @Data public static class Copilot {
        private boolean enabled;
        private String githubAppId;
        private String webhookSecret;
        private String privateKeyPath;
        private String backendUrl;
    }

    @Data public static class Mcp {
        private boolean enabled;
        private int port;
        private String authToken;
        private String logServerUrl;
    }
}
