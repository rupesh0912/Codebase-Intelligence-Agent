package com.codebaseagent.graph;

import com.codebaseagent.AgentConfig;
import com.codebaseagent.ingestion.CodeChunk;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.*;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class CallGraphService implements AutoCloseable {

    private final Driver driver;
    private final int maxDepth;

    public CallGraphService(AgentConfig config) {
        AgentConfig.Neo4j nc = config.getNeo4j();
        this.driver = GraphDatabase.driver(nc.getUri(), AuthTokens.basic(nc.getUsername(), nc.getPassword()));
        this.maxDepth = nc.getMaxTraversalDepth();
        log.info("Neo4j connected: {}", nc.getUri());
    }

    public void storeCallEdges(CodeChunk chunk) {
        try (Session s = driver.session()) {
            s.run("MERGE (c:Class {name:$cls, file:$file}) MERGE (m:Method {name:$method, class:$cls, file:$file}) MERGE (c)-[:HAS_METHOD]->(m)",
                  Map.of("cls", chunk.getClassName(), "method", chunk.getMethodName(), "file", chunk.getFilePath()));
            for (String callee : chunk.getCalls()) {
                s.run("MERGE (caller:Method {name:$caller, class:$cls}) MERGE (callee:Method {name:$callee}) MERGE (caller)-[:CALLS]->(callee)",
                      Map.of("caller", chunk.getMethodName(), "cls", chunk.getClassName(), "callee", callee));
            }
        } catch (Exception e) {
            log.warn("Neo4j write error {}.{}: {}", chunk.getClassName(), chunk.getMethodName(), e.getMessage());
        }
    }

    public List<String> findCallers(String m) {
        try (Session s = driver.session()) {
            return s.run("MATCH (caller:Method)-[:CALLS]->(m:Method {name:$m}) RETURN caller.name AS name", Map.of("m", m))
                    .list(r -> r.get("name").asString());
        }
    }

    public List<String> findCallees(String m) {
        try (Session s = driver.session()) {
            return s.run("MATCH (m:Method {name:$m})-[:CALLS]->(callee:Method) RETURN callee.name AS name", Map.of("m", m))
                    .list(r -> r.get("name").asString());
        }
    }

    public List<String> tracePath(String from, String to) {
        try (Session s = driver.session()) {
            return s.run("MATCH path=(a:Method {name:$from})-[:CALLS*1.." + maxDepth + "]->(b:Method {name:$to}) RETURN [n IN nodes(path)|n.name] AS chain LIMIT 5",
                    Map.of("from", from, "to", to)).list(r -> r.get("chain").asList(v -> v.asString()).toString());
        }
    }

    @Override public void close() { driver.close(); }
}
